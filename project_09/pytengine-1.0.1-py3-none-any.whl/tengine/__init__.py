#!/usr/bin/env python

# coding: utf-8
"""Tengine is a software development kit for front-end intelligent devices developed by OPENAILAB"""



from .tengine import tg

