# coding: utf-8
"""Information about Tengine."""
import ctypes
from .base import _LIB
from .base import check_call, c_str, log_print_t, cpu_info
from .graph import Graph
from .context import Context
from .node import Node
from .tensor import Tensor
from .device import Device
import os
import gc
# gc.set_threshold(9999)

class Tengine(object):
    """initialize the tengine"""

    def __init__(self):
        """
        Initialize the tengine, only can be called once.
        """
        check_call(_LIB.init_tengine())
        self.log_lever = property(None, self.__log_lever)
        self.log_print = property(None, self.__log_output)
        self.plugin = self.Plugin()

        self.Graph = Graph
        self.Context = Context
        self.Node = Node
        self.Tensor = Tensor
        self.Device = Device

        self.run_graph = None

        (self.TENGINE_DT_FP32,
         self.TENGINE_DT_FP16,
         self.TENGINE_DT_INT8,
         self.TENGINE_DT_UINT8,
         self.TENGINE_DT_INT32,
         self.TENGINE_DT_INT16) = map(int, range(6))

        # /* layout type, not real layout */
        (self.TENGINE_LAYOUT_NCHW,
         self.TENGINE_LAYOUT_NHWC) = map(int, range(2))

        # /* tensor type: the content changed or not during inference */
        (self.TENSOR_TYPE_UNKNOWN,
         self.TENSOR_TYPE_VAR,
         self.TENSOR_TYPE_CONST,
         self.TENSOR_TYPE_INPUT,
         self.TENSOR_TYPE_DEP) = map(int, range(5))

        # /* node dump action definition */
        (self.NODE_DUMP_ACTION_DISABLE,
         self.NODE_DUMP_ACTION_ENABLE,
         self.NODE_DUMP_ACTION_START,
         self.NODE_DUMP_ACTION_STOP,
         self.NODE_DUMP_ACTION_GET) = map(int, range(5))

        # /* graph perf action definition */
        (self.GRAPH_PERF_STAT_DISABLE,
         self.GRAPH_PERF_STAT_ENABLE,
         self.GRAPH_PERF_STAT_STOP,
         self.GRAPH_PERF_STAT_START,
         self.GRAPH_PERF_STAT_RESET,
         self.GRAPH_PERF_STAT_GET) = map(int, range(6))

        # /* quant mode */
        (self.TENGINE_QUANT_FP16,
         self.TENGINE_QUANT_INT8,
         self.TENGINE_QUANT_UINT8) = map(int, range(3))

        # /*follow the std. UNIX log level definitioin */
        (self.LOG_EMERG,
         self.LOG_ALERT,
         self.LOG_CRIT,
         self.LOG_ERR,
         self.LOG_WARNING,
         self.LOG_NOTICE,
         self.LOG_INFO,
         self.LOG_DEBUG
         ) = map(int, range(8))

        # * todo: should add suspend? */
        (
            self.GRAPH_STAT_CREATED,
            self.GRAPH_STAT_READY,
            self.GRAPH_STAT_RUNNING,
            self.GRAPH_STAT_DONE,
            self.GRAPH_STAT_ERROR
        ) = map(int, range(5))

        # /* graph_exec_event */
        (
            self.GRAPH_EXEC_START,
            self.GRAPH_EXEC_SUSPEND,
            self.GRAPH_EXEC_RESUME,
            self.GRAPH_EXEC_ABORT,
            self.GRAPH_EXEC_DONE
        ) = map(int, range(5))

        # /* device_policy */
        (
            self.DEFAULT_POLICY,
            self.LATENCY_POLICY,
            self.LOW_POWER_POLICY
        ) = map(int, range(3))

    def __del__(self):
        """
        Release the tengine, only can be called once.
        :return: None
        """
        print("release tengine")
        _LIB.release_tengine()

    def run_model(self, model, input_data, shape, model_file=None, context=None):
        """
        run caffe tf mxnet onnx tengine models
        :param model: <str> model file
        :param input_data: <np.ndarray> input data
        :param shape: <list> input shape
        :param model_file: <str> prototxt or params or json file
        :param context: <context object> or None
        :return: output tensor's buffer, graph
        """
        model_type = model.split('.')[-1]
        output_tensor = None
        if model_type == 'caffemodel' or model_type == 'prototxt':
            if not self.run_graph:
                self.run_graph = self.Graph(context, 'caffe', model_file if model_type == 'caffemodel' else model,
                                                  model if model_type == 'caffemodel' else model_file)
                self.run_graph.preRun()
            input_tensor = self.run_graph.getInputTensor(0, 0)
            input_tensor.shape = shape
            input_tensor.buf = input_data
            self.run_graph.run(block=1)
            output_tensor = self.run_graph.getOutputTensor(0, 0)

        elif model_type == 'tmfile':
            if not self.run_graph:
                self.run_graph = self.Graph(context, 'tengine', model)
                self.run_graph.preRun()
            input_tensor = self.run_graph.getInputTensor(0, 0)
            input_tensor.shape = shape
            input_tensor.buf = input_data
            self.run_graph.run(block=1)
            output_tensor = self.run_graph.getOutputTensor(0, 0)

        elif model_type == 'pb':
            if not self.run_graph:
                self.run_graph = self.Graph(context, 'tensorflow', model)
                input_tensor = self.run_graph.getInputTensor(0, 0)
                input_tensor.shape = shape
                self.run_graph.preRun()
            input_tensor = self.run_graph.getInputTensor(0, 0)
            input_tensor.buf = input_data
            self.run_graph.run(block=1)
            output_tensor = self.run_graph.getOutputTensor(0, 0)

        elif model_type == 'model' and model.split('.')[-2] == 'onnx':
            if not self.run_graph:
                self.run_graph = self.Graph(context, 'onnx', model)
                self.run_graph.preRun()
            input_tensor = self.run_graph.getInputTensor(0, 0)
            input_tensor.shape = shape
            input_tensor.buf = input_data
            self.run_graph.run(block=1)
            output_tensor = self.run_graph.getOutputTensor(0, 0)

        elif model_type == 'json' or model_type == 'params':
            if not self.run_graph:
                self.run_graph = self.Graph(context, 'mxnet', model if model_type == 'json' else model_file, model_file
                                            if model_type == 'json' else model)
                input_tensor = self.run_graph.getInputTensor(0, 0)
                input_tensor.shape = shape
                self.run_graph.preRun()
            input_tensor = self.run_graph.getInputTensor(0, 0)
            input_tensor.buf = input_data
            self.run_graph.run(block=1)
            output_tensor = self.run_graph.getOutputTensor(0, 0)

        out = output_tensor.getbuffer(float)
        return out, self.run_graph

    @property
    def __errno__(self):
        """
        return the error number
        list of the symbolic error name follows glibc definitions
        :return: <int> error number
        """
        return _LIB.get_tengine_errno()

    @property
    def __version__(self):
        """
        Get the version of the tengine.
        :return: <str>
        """
        _LIB.get_tengine_version.restype = ctypes.c_char_p
        return _LIB.get_tengine_version()

    def requestTengineVersion(self, version):
        """
        Check the run-time library supports the verson.
        :param version: <str> version: A c string returned by tg.__version__
        :return: 1: support, 0: not support
        """
        return _LIB.request_tengine_version(c_str(version))

    def setDefaultDevice(self,dev_name):
        """
        set The default device.
        :param dev_name: <str> The device name.
        :return: None
        """
        check_call(_LIB.set_default_device(c_str(dev_name)))

    def __log_lever(self, value):
        """
        Set the logger level.
        :param value: <log_level> The log level. like: tg.LOG_EMERG, tg.LOG_ALERT, etc.
        :return: None
        """
        self.log_level = value
        _LIB.set_log_level(ctypes.c_int(value))

    def __log_output(self, func):
        """
        set the print function of log.
        :param func: python function like: def function(str): ...
        :return: None
        """
        _LIB.set_log_output(log_print_t(func))

    def get_predefined_cpu(self,name):
        _LIB.get_predefined_cpu.restype = ctypes.POINTER(cpu_info)
        return _LIB.get_predefined_cpu(c_str(name))[0]

    def set_online_cpu(self,cpu_info,cpu_list):
        cpu_list = (ctypes.c_int * len(cpu_list))(*cpu_list)
        return _LIB.set_online_cpu(ctypes.byref(cpu_info), ctypes.byref(cpu_list), len(cpu_list))

    def create_cpu_device(self,name,cpu_info):
        return _LIB.create_cpu_device(c_str(name), ctypes.byref(cpu_info))

    class Plugin(object):
        def __init__(self):
            self.pluginList = []
            pass

        def add(self, name, fname, init_func):
            """
            Load one plugin from disk, and execute the init function.
            :param name:  <str> plugin_name: Plugin name.
            :param fname: <str> fname: Plugin file name.
            :param init_func: The name of the init function.
            :return: None
            """
            self.pluginList.append(name)
            check_call(_LIB.load_tengine_plugin(c_str(name), c_str(fname), c_str(init_func)))

        def remove(self, name, del_func):
            """
            Unload one plugin and call the release function.
            :param name: <str> plugin_name: The name of plugin.
            :param del_func: <str> rel_func_name: The release function name.
            :return: None
            """
            self.pluginList.remove(name)
            check_call(_LIB.unload_tengine_plugin(c_str(name), c_str(del_func)))

        def __len__(self):
            """
            Get the number of loaded plugin.
            :return: <int> The plugin number.
            """
            return _LIB.get_tengine_plugin_number()

        def __getitem__(self, item):
            """
            Get the name of idx plugin.
            :param item: <int> The index of loaded plugin.
            :return: The name of plugin.
            """
            if type(item) is int:
                _LIB.get_tengine_plugin_name.restype = ctypes.c_char_p
                return _LIB.get_tengine_plugin_name(item)
            else:
                return None


tg = Tengine()

from .ops import *
tg.Conv2d = conv2d
tg.Pooling = pooling
tg.Input = input_op
tg.Concat = concat
tg.Eltwise = eltwise
tg.FullyConnected = fc
tg.Flatten = flatten
tg.Deconv2d = deconv2d
tg.Softmax = soft_max
tg.Batchnorm = bn
tg.Relu = relu
tg.Lrn = lrn
tg.Rnn = rnn
tg.Lstm = lstm
tg.Reshape = reshape
tg.Permute = permute
tg.Slice = slice
tg.Reduction = reduction
tg.Shuffle_channel = shuffle_channel
tg.Add_n = Add_n
tg.Relu6 = relu6
tg.Split = split
tg.Batch_to_space_nd = batch_to_space_nd
tg.Space_to_batch_nd = space_to_batch_nd
tg.Dropout = dropout
tg.Normalize = normalize
tg.Resize = resize
tg.PRelu = prelu
tg.Clip = clip
tg.Pad = pad
tg.Sigmoid = sigmoid
tg.Squeeze = squeeze
tg.Swap_axis = swap_axis