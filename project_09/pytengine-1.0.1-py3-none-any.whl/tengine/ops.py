import os
import numpy as np
from .tengine import tg


def input_op(graph, name, input_shape):
    """
    :param graph: the graph already created
    :return: None
    """
    input_node = tg.Node(graph, name, 'InputOp')
    tensor = tg.Tensor(graph=graph, name=name, type=tg.TENGINE_DT_FP32)
    tensor.shape = input_shape
    input_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_INPUT)


def node_manager( graph, name, input_tensor_name, op_name, output_num):
    """
    :param graph: the graph already created
    :param name: name of the node also its output tensor's name
    :param last_one_name: name of the node before this node
    :param op_name: <str>Tengine's op name
    :return: the prepared node
    """
    node = tg.Node(graph, name, op_name)
    if isinstance(input_tensor_name, list):
        for i in range(len(input_tensor_name)):
            nodes_input_tensor = graph.getTensorByName(input_tensor_name[i])
            node.setInputTensorByIdx(i, nodes_input_tensor)

    else:
        nodes_input_tensor = graph.getTensorByName(input_tensor_name)
        node.setInputTensorByIdx(0, nodes_input_tensor)

    for i in range(output_num):
        nodes_output_tensor = tg.Tensor(graph=graph, name=name + '_' + str(i), type=tg.TENGINE_DT_FP32)
        node.setOutputTensorByIdx(i, nodes_output_tensor, tg.TENSOR_TYPE_VAR)
    return node


def conv2d(graph, name, input_tensor_name, k_size, stride=[1, 1], pad=[0, 0, 0, 0], in_channel=None,
           out_channel=None, groups=1, dilation=[1, 1], weight=None, bias=None, node=None, output_num=1):
    """
    :param graph: the graph already created
    :param name: name of the Convolution node
    :param last_one_name: name of the node before this node
    :param kernel_size: kernel size
    :param stride: stride
    :param pad: pad
    :param in_channel: in channel
    :param out_channel: out channel
    :param group: group
    :return: None
    """
    conv_node = node_manager(graph, name, input_tensor_name, 'Convolution', output_num=output_num)

    if type(weight) is np.ndarray:
        w_tensor = weights(graph, name, kernel_size=k_size, out_channel=out_channel, in_channel=in_channel, weights=weight)
        conv_node.setInputTensorByIdx(output_num, w_tensor)

    if type(bias) is np.ndarray:
        b_tensor = biass(graph, name, bias=bias)
        conv_node.setInputTensorByIdx(output_num + 1, b_tensor)

    conv_node.setAttr('kernel_h', k_size[0])
    conv_node.setAttr('kernel_w', k_size[1])
    conv_node.setAttr('stride_h', stride[0])
    conv_node.setAttr('stride_w', stride[1])
    conv_node.setAttr("pad_h0", pad[0])
    conv_node.setAttr("pad_w0", pad[1])
    conv_node.setAttr("pad_h1", pad[2])
    conv_node.setAttr("pad_w1", pad[3])
    conv_node.setAttr("output_channel", out_channel)
    conv_node.setAttr("input_channel", in_channel)
    conv_node.setAttr("group", groups)
    conv_node.setAttr("dilation_h", dilation[0])
    conv_node.setAttr("dilation_w", dilation[1])


def deconv2d(graph, name, input_tensor_name, k_size=[1, 1], stride=[1, 1], pad=[0, 0, 0, 0], groups=1, dilation=[1, 1],
             weight=None, bias=None, node=None, num_output=1, in_channel=None, out_channel=None):
    deconv_node = node_manager(graph, name, input_tensor_name, 'Deconvolution', output_num=num_output)

    deconv_node.setAttr('kernel_h', k_size[0])
    deconv_node.setAttr('kernel_w', k_size[1])
    deconv_node.setAttr('stride_h', stride[0])
    deconv_node.setAttr('stride_w', stride[1])
    deconv_node.setAttr("pad_h0", pad[0])
    deconv_node.setAttr("pad_w0", pad[1])
    deconv_node.setAttr("pad_h1", pad[2])
    deconv_node.setAttr("pad_w1", pad[3])
    deconv_node.setAttr("group", groups)
    deconv_node.setAttr("dilation_h", dilation[0])
    deconv_node.setAttr("dilation_w", dilation[1])
    deconv_node.setAttr('num_output', num_output)

    if type(weight) is np.ndarray:
        w_tensor = weights(graph, name, kernel_size=k_size, out_channel=out_channel, in_channel=in_channel, weights=weight)
        deconv_node.setInputTensorByIdx(num_output, w_tensor)

    if type(bias) is np.ndarray:
        b_tensor = biass(graph, name, bias=bias)
        deconv_node.setInputTensorByIdx(num_output + 1, b_tensor)


def eltwise(graph, name, input_tensor_name, otype='2', caffe_flavor=True):
    eltwise_node = node_manager(graph, name, input_tensor_name, 'Eltwise', output_num=1)
    caffe_flavor = 1 if caffe_flavor else 0
    eltwise_node.setAttr('caffe_flavor', caffe_flavor)

    elttype = ['prod', 'prod_scalar', 'sum', 'sum_scalar', 'sub', 'sub_scalar', 'max', 'rsqrt', 'min_scalar',
               'last', 'div', 'log', 'exp', 'sqrt', 'floor', 'square', 'pow']

    if otype not in elttype:
        raise ValueError('Unsupported algorithm')
    else:
        eltwise_node.setAttr('type', elttype.index(otype))


def bn(graph, name, input_tensor_name, weight, bias=None, mean=None, var=None, caffe_flavor=False):
    """
    :param graph: the graph already created
    :param name: name of the BatchNormalization node
    :param last_one_name: name of the node before this node
    :param out_channel: out channel
    :return: None
    """
    bn_node = node_manager(graph, name, input_tensor_name, 'BatchNormalization', output_num=1)
    bn_node.setAttr('caffe_flavor', 1 if caffe_flavor else 0)

    w_tensor = weights(graph, name, weights=weight)
    bn_node.setInputTensorByIdx(1, w_tensor)

    if bias is None:
        bias = np.array([0])
    b_tensor = biass(graph, name, bias=bias)
    bn_node.setInputTensorByIdx(2, b_tensor)

    if mean is None:
        mean = np.array([0])
    m_tensor = mean_v(graph, name, mean, t_type='mean')
    bn_node.setInputTensorByIdx(3, m_tensor)

    if var is None:
        var = np.array([0])
    v_tensor = mean_v(graph, name, var, t_type='var')
    bn_node.setInputTensorByIdx(4, v_tensor)


def relu(graph, name, input_tensor_name, negative_slope=0.0):
    """
    :param graph: the graph already created
    :param name: name of the Relu node
    :param last_one_name: name of the node before this node
    :return: None
    """
    relu_node = node_manager(graph, name, input_tensor_name, 'ReLu', output_num=1)
    relu_node.setAttr('negative_slope', negative_slope)


def pooling(graph, name, input_tensor_name, k_size=[2, 2], stride=[1, 1], pad=[0, 0, 0, 0], alg='max',
            caffe_flavor=False, is_global=False):
    """
    :param graph: the graph already created
    :param name: name of the Pooling node
    :param last_one_name: name of the node before this node
    :return:None
    """
    g = 1 if is_global else 0
    a = 1 if alg == 'avg' else 0
    caffe_flavor = 1 if caffe_flavor else 0
    pooling_node = node_manager(graph, name, input_tensor_name, 'Pooling', output_num=1)
    pooling_node.setAttr('kernel_h', k_size[0])
    pooling_node.setAttr('kernel_w', k_size[1])
    pooling_node.setAttr('stride_h', stride[0])
    pooling_node.setAttr('stride_w', stride[1])
    pooling_node.setAttr('pad_h0', pad[0])
    pooling_node.setAttr('pad_w0', pad[1])
    pooling_node.setAttr('pad_h1', pad[2])
    pooling_node.setAttr('pad_w1', pad[3])
    pooling_node.setAttr('global', g)

    pooling_node.setAttr('alg', a)
    pooling_node.setAttr('caffe_flavor', caffe_flavor)


def concat(graph, name, input_tensor_name, axis=1):
    concat_node = node_manager(graph, name, input_tensor_name, 'Concat', output_num=1)
    concat_node.setAttr('axis', axis)


def flatten(graph, name, input_tensor_name, axis=1, end_axis=3):
    flatten_node = node_manager(graph, name, input_tensor_name, 'Flatten', output_num=1)
    flatten_node.setAttr('axis', axis)
    flatten_node.setAttr('end_axis', end_axis)


def fc(graph, name, input_tensor_name, weight, bias=None):
    """
    :param graph: the graph already created
    :param name: name of the FullyConnected node
    :param last_one_name: name of the node before this node
    :return:None
    """
    fc_node = node_manager(graph, name, input_tensor_name, 'FullyConnected', output_num=1)

    w_tensor = weights(graph, name, weights=weight)
    fc_node.setInputTensorByIdx(1, w_tensor)

    if type(bias) is np.ndarray:
        b_tensor = biass(graph, name, bias=bias)
        fc_node.setInputTensorByIdx(2, b_tensor)

    fc_node.setAttr('num_output', weight.shape[0])


def soft_max(graph, name, input_tensor_name, axis=1):
    softmax_node = node_manager(graph, name, input_tensor_name, 'Softmax', output_num=1)
    softmax_node.setAttr('axis', axis)


def weights(graph, name, kernel_size=None, out_channel=None, in_channel=None, weights=None):
    """
    :param graph: the graph already created
    :param name: the weights tensor's prefix name
    :return: weight tensor
    """
    weights_node = tg.Node(graph, name + '/weights', 'Const')
    tensor = tg.Tensor(graph=graph, name=(name + '/weights'), type=tg.TENGINE_DT_FP32)

    if kernel_size:
        tensor.shape = [out_channel, in_channel, kernel_size[0], kernel_size[1]]
    else:
        tensor.shape = weights.shape
    tensor.buf = weights
    weights_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    return tensor


def biass(graph, name, bias):
    """
    :param graph: the graph already created
    :param name: the bias tensor's prefix name
    :return: bias tensor
    """
    bias_node = tg.Node(graph, name + '/bias', 'Const')
    tensor = tg.Tensor(graph=graph, name=(name + '/bias'), type=tg.TENGINE_DT_FP32)
    tensor.shape = bias.shape
    tensor.buf = bias
    bias_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    return tensor


def mean_v(graph, name, param, t_type=None):
    """
    :param graph: the graph already created
    :param name: the bias tensor's prefix name
    :param out_channel: out channel
    :param t_type: <str>param's name (running_mean, running_var...)
    :return: param's(running_mean, running_var...) tensor
    """
    node = tg.Node(graph, name + t_type, 'Const')
    tensor = tg.Tensor(graph=graph, name=(name + t_type), type=tg.TENGINE_DT_FP32)
    tensor.shape = param.shape
    tensor.buf = param
    node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    return tensor


def lrn(graph, name, input_tensor_name, local_size=5, norm_region=0, alpha=1.0, beta=0.75, k=1.0):
    lrn_node = node_manager(graph, name, input_tensor_name, 'LRN', output_num=1)
    lrn_node.setAttr('local_size', local_size)
    lrn_node.setAttr('norm_region', norm_region)
    lrn_node.setAttr('alpha', alpha)
    lrn_node.setAttr('beta', beta)
    lrn_node.setAttr('k', k)

def reshape(graph, name, input_tensor_name, size):
    reshape_node = node_manager(graph, name, input_tensor_name, 'Reshape', output_num=1)
    for i in range(len(size)):
        reshape_node.setAttr('dim_{}'.format(i), size[i])
    reshape_node.setAttr('dim_size', 0)

def permute(graph, name, input_tensor_name, order):
    permute_node = node_manager(graph, name, input_tensor_name, 'Permute', output_num=1)
    permute_node.setAttr('order0', order[0])
    permute_node.setAttr('order1', order[1])
    permute_node.setAttr('order2', order[2])
    permute_node.setAttr('order3', order[3])
    permute_node.setAttr('flag', 0)

def slice(graph, name, input_tensor_name, axis=0, is_caffe=True, output_num=2):
    is_caffe = 1 if is_caffe else 0
    slice_node = node_manager(graph, name, input_tensor_name, 'Slice', output_num=output_num)
    slice_node.setAttr('axis', axis)
    slice_node.setAttr('iscaffe', is_caffe)

def rnn(graph, name, input_tensor_name, output_num=1, clip=0.0, output_len=1, sequence_len=1, input_size=1, hidden_size=1,
        has_clip=False, has_bias=False, has_init_state=False, weight=None, bias=None):
    rnn_node = node_manager(graph, name, input_tensor_name, 'RNN', output_num=output_num)
    rnn_node.setAttr('clip', clip)
    rnn_node.setAttr('output_len', output_len)
    rnn_node.setAttr('sequence_len', sequence_len)
    rnn_node.setAttr('input_size', input_size)
    rnn_node.setAttr('hidden_size', hidden_size)
    rnn_node.setAttr('has_clip', has_clip)
    rnn_node.setAttr('has_bias', has_bias)
    rnn_node.setAttr('has_init_state', has_init_state)

    if type(weight) is np.ndarray:
        weight_tensor = weights(graph, name, weights=weight)
        rnn_node.setInputTensorByIdx(1, weight_tensor)

    if has_bias and type(bias) is np.ndarray:
        bias_tensor = biass(graph, name, bias)
        rnn_node.setInputTensorByIdx(2, bias_tensor)

def lstm(graph, name, input_tensor_name, output_num=1, forget_bias=0.0, clip=0.0, output_len=1, sequence_len=1, input_size=1,
         hidden_size=1, cell_size=1, has_projection=False, has_peephole=False, has_clip=False, has_bias=False, has_init_state=False,
         weight=None, bias=None, proj_tensor=None, kernel_tensor=None, w_f_tensor=None, w_i_tensor=None, w_o_tensor=None,
         fused_kernel_tensor=None):
    lstm_node = node_manager(graph, name, input_tensor_name, 'LSTM', output_num=output_num)
    lstm_node.setAttr('forget_bias', forget_bias)
    lstm_node.setAttr('clip', clip)
    lstm_node.setAttr('output_len', output_len)
    lstm_node.setAttr('sequence_len', sequence_len)
    lstm_node.setAttr('input_size', input_size)
    lstm_node.setAttr('hidden_size', hidden_size)
    lstm_node.setAttr('cell_size', cell_size)
    lstm_node.setAttr('has_projection', has_projection)
    lstm_node.setAttr('has_peephole', has_peephole)
    lstm_node.setAttr('has_clip', has_clip)
    lstm_node.setAttr('has_bias', has_bias)
    lstm_node.setAttr('has_init_state', has_init_state)

    if type(weight) is np.ndarray:
        weight_tensor = lstm_const(graph, 'weight_tensor', param=weight)
        lstm_node.setInputTensorByIdx(1, weight_tensor)

    if has_bias and type(bias) is np.ndarray:
        bias_tensor = lstm_const(graph, 'bias_tensor', param=bias)
        lstm_node.setInputTensorByIdx(2, bias_tensor)

    if has_projection and type(proj_tensor) is np.ndarray:
        projection = lstm_const(graph, 'proj_tensor', param=proj_tensor)
        lstm_node.setInputTensorByIdx(3, projection)

    if type(fused_kernel_tensor) is np.ndarray:
        fused_tensor = lstm_const(graph, 'fused_kernel_tensor', param=fused_kernel_tensor)
        lstm_node.setInputTensorByIdx(4, fused_tensor)

    if type(kernel_tensor) is np.ndarray:
        k_tensor = lstm_const(graph, 'kernel_tensor', param=kernel_tensor)
        lstm_node.setInputTensorByIdx(5, k_tensor)

    if has_peephole:
        if type(w_f_tensor) is np.ndarray:
            wf_tensor = lstm_const(graph, 'w_f_tensor', param=w_f_tensor)
            lstm_node.setInputTensorByIdx(6, wf_tensor)

        if type(w_i_tensor) is np.ndarray:
            wi_tensor = lstm_const(graph, 'w_i_tensor', param=w_i_tensor)
            lstm_node.setInputTensorByIdx(7, wi_tensor)

        if type(w_o_tensor) is np.ndarray:
            wo_tensor = lstm_const(graph, 'w_o_tensor', param=w_o_tensor)
            lstm_node.setInputTensorByIdx(8, wo_tensor)

def lstm_const(graph, name, param=None):
    """
    :param graph: the graph already created
    :param name: the weights tensor's prefix name
    :return: weight tensor
    """
    param_node = tg.Node(graph, name, 'Const')
    tensor = tg.Tensor(graph=graph, name=name, type=tg.TENGINE_DT_FP32)
    tensor.shape = param.shape
    tensor.buf = param
    param_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    return tensor

def gemm(graph, name, input_tensor_name, transA=0, transB=0, alpha=1.0, beta=1.0, weight=None, bias=None):
    gemm_node = node_manager(graph, name, input_tensor_name, 'Gemm', output_num=1)
    gemm_node.setAttr('alpha', alpha)
    gemm_node.setAttr('beta', beta)
    gemm_node.setAttr('transA', transA)
    gemm_node.setAttr('transB', transB)

    if type(weight) is np.ndarray:
        w_tensor = weights(graph, name, weights=weight)
        gemm_node.setInputTensorByIdx(1, w_tensor)

    if type(bias) is np.ndarray:
        b_tensor = biass(graph, name, bias=bias)
        gemm_node.setInputTensorByIdx(2, b_tensor)

def reduction(graph, name, input_tensor_name, dim=[-2, -2, -2 ,-2], type='sum', keepdim=0):
    reduction_node = node_manager(graph, name, input_tensor_name, 'Reduction', output_num=1)
    reduction_node.setAttr('dim_0', dim[0])
    reduction_node.setAttr('dim_1', dim[1])
    reduction_node.setAttr('dim_2', dim[2])
    reduction_node.setAttr('dim_3', dim[3])
    reduction_node.setAttr('keepdim', keepdim)
    if type == 'sum':
        o_type = 0
    elif type == 'mean':
        o_type = 1
    else:
        raise ValueError
    reduction_node.setAttr('type', o_type)

def shuffle_channel(graph, name, input_tensor_name, group=1):
    shuffle_node = node_manager(graph, name, input_tensor_name, 'ShuffleChannel', output_num=1)
    shuffle_node.setAttr('group', group)

def Add_n(graph, name, input_tensor_name):
    add_n_node = node_manager(graph, name, input_tensor_name, 'Addn', output_num=1)

def relu6(graph, name, input_tensor_name):
    """
    :param graph: the graph already created
    :param name: name of the Relu node
    :param last_one_name: name of the node before this node
    :return: None
    """
    relu6_node = node_manager(graph, name, input_tensor_name, 'ReLu6', output_num=1)

def split(graph, name, input_tensor_name, axis=0, split_dim=1, is_caffe=False):
    split_node = node_manager(graph, name, input_tensor_name, 'Split', output_num=split_dim)
    split_node.setAttr('axis', axis)
    split_node.setAttr('split_dim', split_dim)
    split_node.setAttr('is_caffe', is_caffe)


def batch_to_space_nd(graph, name, input_tensor_name, dilation=[1, 1], crop=[[0, 0], [0, 0]]):
    node = node_manager(graph, name, input_tensor_name, 'BatchToSpaceND', output_num=1)
    node.setAttr("dilation_x", dilation[0])
    node.setAttr("dilation_y", dilation[1])
    node.setAttr("crop_top", crop[0][0])
    node.setAttr("crop_bottom", crop[0][1])
    node.setAttr("crop_left", crop[1][0])
    node.setAttr("crop_right", crop[1][1])


def space_to_batch_nd(graph, name, input_tensor_name, dilation=[1, 1], crop=[[0, 0], [0, 0]]):
    node = node_manager(graph, name, input_tensor_name, 'SpaceToBatchND', output_num=1)
    node.setAttr("dilation_x", dilation[0])
    node.setAttr("dilation_y", dilation[1])
    node.setAttr("pad_top", crop[0][0])
    node.setAttr("pad_bottom", crop[0][1])
    node.setAttr("pad_left", crop[1][0])
    node.setAttr("pad_right", crop[1][1])


def dropout(graph, name, input_tensor_name):
    dropout_node = node_manager(graph, name, input_tensor_name, 'Dropout', output_num=1)

def normalize(graph, name, input_tensor_name, scale, across_spatial=False, channel_shared=False):
    normalize_node = node_manager(graph, name, input_tensor_name, 'Normalize', output_num=1)
    across_spatial = 1 if across_spatial else 0
    channel_shared = 1 if channel_shared else 0
    normalize_node.setAttr('across_spatial', across_spatial)
    normalize_node.setAttr('channel_shared', channel_shared)

    scale_node = tg.Node(graph, name + '/scale', 'Const')
    tensor = tg.Tensor(graph=graph, name=(name + '/scale'), type=tg.TENGINE_DT_FP32)
    tensor.shape = scale.shape
    tensor.buf = scale
    scale_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    normalize_node.setInputTensorByIdx(1, tensor)

def resize(graph, name, input_tensor_name, scale=[1, 1], type=0):
    resize_node = node_manager(graph, name, input_tensor_name, 'Resize', output_num=1)
    resize_node.setAttr('scale_h', float(scale[0]))
    resize_node.setAttr('scale_w', float(scale[1]))
    resize_node.setAttr('type', type)

def prelu(graph, name, input_tensor_name, slope):
    prelu_node = node_manager(graph, name, input_tensor_name, 'PReLU', output_num=1)

    slope_node = tg.Node(graph, name + '/slope', 'Const')
    tensor = tg.Tensor(graph=graph, name=(name + '/slope'), type=tg.TENGINE_DT_FP32)
    tensor.shape = slope.shape
    tensor.buf = slope
    slope_node.setOutputTensorByIdx(0, tensor, tg.TENSOR_TYPE_CONST)
    prelu_node.setInputTensorByIdx(1, tensor)

def clip(graph, name, input_tensor_name, max=0, min=0):
    clip_node = node_manager(graph, name, input_tensor_name, 'Clip', output_num=1)
    clip_node.setAttr('max', float(max))
    clip_node.setAttr('min', float(min))

def pad(graph, name, input_tensor_name, mode=0, value=0, pad=[[-1, -1], [-1, -1], [-1, -1], [-1, -1]]):
    pad_node = node_manager(graph, name, input_tensor_name, 'Pad', output_num=1)
    pad_node.setAttr("mode", mode)
    pad_node.setAttr("pad_0_h", pad[0][0])
    pad_node.setAttr("pad_0_w", pad[0][1])
    pad_node.setAttr("pad_1_h", pad[1][0])
    pad_node.setAttr("pad_1_w", pad[1][1])
    pad_node.setAttr("pad_2_h", pad[2][0])
    pad_node.setAttr("pad_2_w", pad[2][1])
    pad_node.setAttr("pad_3_h", pad[3][0])
    pad_node.setAttr("pad_3_w", pad[3][1])
    pad_node.setAttr("value", float(value))

def sigmoid(graph, name, input_tensor_name):
    sigmoid_node = node_manager(graph, name, input_tensor_name, 'Sigmoid', output_num=1)

def squeeze(graph, name, input_tensor_name, dim=[-2, -2, -2, -2]):
    squeeze_node = node_manager(graph, name, input_tensor_name, 'Squeeze', output_num=1)
    squeeze_node.setAttr('dim_0', dim[0])
    squeeze_node.setAttr('dim_1', dim[1])
    squeeze_node.setAttr('dim_2', dim[2])
    squeeze_node.setAttr('dim_3', dim[3])

def swap_axis(graph, name, input_tensor_name, dim=[0, 1]):
    swap_axis_node = node_manager(graph, name, input_tensor_name, 'SwapAxis', output_num=1)
    swap_axis_node.setAttr('dim_0', dim[0])
    swap_axis_node.setAttr('dim_1', dim[1])
